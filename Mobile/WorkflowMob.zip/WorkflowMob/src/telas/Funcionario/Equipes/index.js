import React, { useState, useEffect } from 'react'; 
import { Text, View, Image, TextInput, TouchableOpacity, ScrollView,  ActivityIndicator} from 'react-native';
import { Card, Title, Paragraph } from 'react-native-paper';
import { useFocusEffect } from '@react-navigation/native';
import { getStyles } from './style';
import { useTheme } from '../../../styles/themecontext'

import api from '../../../../services/api';
import url from '../../../../services/url';

export default function Equipes({ route, navigation }) {
  const { theme } = useTheme();
  const styles = getStyles(theme);
  
  const usuario = route.params?.usuario;
  const [dados, setDados] = useState([]);
  const [equipeSelecionada, setEquipeSelecionada] = useState(null)
  const [isLoading, setIsLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState(null);
  const [termoBusca, setTermoBusca] = useState('');
  const [usuarioState, setusuarioState] = useState(usuario);

  useFocusEffect(
  React.useCallback(() => {
    listarDados();
  }, [])
  );

  useEffect(() => {
  if (route.params?.usuario) {
    setusuarioState(route.params.usuario);
  }
  }, [route.params?.usuario]);


  async function listarDados() {
  if (!usuario?.FuncionarioId) {
        console.log("ID do usuário não disponível");
        return;
  }
  
  try {
    setIsLoading(true);
    setErrorMessage(null);
    console.log("ID do Funcionario enviado:", usuario.FuncionarioId);
    const res = await api.get(`dev4tech/equipe.php`, {
      params: {
        id_funcionario: usuario.FuncionarioId // Use o ID do usuário logado
      }
    });

    if (res.data.success) {
      setDados(res.data.result || []);
    } else {
      console.log("Erro na API:", res.data.message);
      setDados([]);
    }
  }
  catch (error) {
    console.log("Erro ao listar equipes:", error);
    setErrorMessage("Erro de conexão com o servidor");
  }
  finally {
    setIsLoading(false);
  }
  }

  useEffect(() => {
    listarDados();
  }, [usuarioState?.FuncionarioId]);

  const toggleEquipe = (FuncionarioId) => {
    setEquipeSelecionada(equipeSelecionada === FuncionarioId ? null : FuncionarioId);
  };

  if (isLoading) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <ActivityIndicator size="large" color={theme.primary} />
      </View>
    );
  }

  if (errorMessage) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <Text style={{ color: 'red' }}>{errorMessage}</Text>
        <TouchableOpacity onPress={listarDados}>
          <Text>Tentar novamente</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const filtrarEquipes = () => {
    let tarefasFiltradas = dados;
    
    // Aplica filtro de busca
    if (termoBusca) {
      const termo = termoBusca.toLowerCase();
      tarefasFiltradas = tarefasFiltradas.filter(item => 
        item.nome_equipe.toLowerCase().includes(termo) || 
        item.nome_categoria.toLowerCase().includes(termo)
      );
    }
    
    return tarefasFiltradas;
  };

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
          <Text style={styles.titulo}>Equipes</Text>
          <TextInput
            style={styles.navinput}
            placeholder="🔍 Pesquisa uma equipe"
            placeholderTextColor="#ffffff"
            value={termoBusca}
            onChangeText={setTermoBusca}
          />
        {dados.length === 0 ? (
          <Text style={{ textAlign: 'center', marginTop: 20 }}>Nenhuma equipe encontrada</Text>
        ) : (
          filtrarEquipes().map(item => (
          <View key={item.id_equipe}>
              <TouchableOpacity
                style={styles.containertarefas}
                onPress={() => toggleEquipe(item.id_equipe)}
              >
                <Image 
                  source={item.foto_url ? { uri: item.foto_url } : require('../../../../assets/img/image.png')} 
                  style={styles.imag} 
                />

                <View style={styles.textos}>
                  <Text style={styles.textolistatitulo}>{item.nome_equipe}</Text>
                  <Text style={styles.textolistacargo}>{item.nome_categoria}</Text>
                </View>
              </TouchableOpacity>
                {equipeSelecionada === item.id_equipe && (
                <View style={styles.areacard}>
                  <TouchableOpacity 
                    onPress={() => navigation.navigate('EquipeFuncionario',  { 
                      equipe: item, 
                      usuario: usuarioState 
                    })}>
                      
                    <Card style={styles.cardtarequi}>
                      <Card.Cover source={require('../../../../assets/img/equipes.png')} style={styles.imagemcard} />
                      <Card.Content style={styles.cardinferior}>
                        <Title style={styles.titulocard}>Funcionarios</Title>
                        <Paragraph style={styles.paragraph}>Vejas os membros da Equipe</Paragraph>
                        <View style={styles.linhainfer}>
                          <Text style={styles.data}>16/07/20</Text>
                          <Text style={styles.Entre}>Entre aqui</Text>
                        </View>
                      </Card.Content>
                    </Card>
                  </TouchableOpacity>

                  <TouchableOpacity 
                    onPress={() => navigation.navigate('EquipeTarefas', { 
                      equipe: item, 
                      usuario: usuarioState  
                    })}>

                    <Card style={styles.cardtarequi}>
                      <Card.Cover source={require('../../../../assets/img/tarefas.png')} style={styles.imagemcard} />
                      <Card.Content style={styles.cardinferior}>
                        <Title style={styles.titulocard}>Tarefas</Title>
                        <Paragraph style={styles.paragraph}>Vejas as Tarefas da equipe</Paragraph>
                        <View style={styles.linhainfer}>
                          <Text style={styles.data}>16/07/20</Text>
                          <Text style={styles.Entre}>Entre aqui</Text>
                        </View>
                      </Card.Content>
                    </Card>

                  </TouchableOpacity>

                  <TouchableOpacity 
                    onPress={() => navigation.navigate('EquipeRanking', { 
                      equipe: item, 
                      usuario: usuarioState  
                    })}>

                    <Card style={styles.cardtarequi}>
                      <Card.Cover source={require('../../../../assets/img/ranking.png')} style={styles.imagemcard} />
                      <Card.Content style={styles.cardinferior}>
                        <Title style={styles.titulocard}>Ranking</Title>
                        <Paragraph style={styles.paragraph}>Veja sua posição entre os membros</Paragraph>
                        <View style={styles.linhainfer}>
                          <Text style={styles.data}>16/07/20</Text>
                          <Text style={styles.Entre}>Entre aqui</Text>
                        </View>
                      </Card.Content>
                    </Card>

                  </TouchableOpacity>
                </View>
              )}
            </View>
            )
          ))}
      </ScrollView>
    </View>
  );
}