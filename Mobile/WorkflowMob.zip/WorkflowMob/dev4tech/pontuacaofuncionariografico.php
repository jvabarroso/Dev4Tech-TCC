<?php
include_once('conexao.php');

$id_equipe = $_GET['id_equipe'] ?? null;

if (empty($id_equipe)) {
    error_log("Erro: ID da Equipe não fornecido");
    echo json_encode([
        'success' => false,
        'message' => 'ID da Equipe não fornecido',
        'received_data' => $_GET 
    ]);
    exit();
}

try {
    $query = $pdo->prepare("SELECT 
        f.funcionarioId, 
        f.nome, 
        COALESCE(SUM(pf.pontos), 0) AS pontos
    FROM equipes_membros em
    INNER JOIN funcionarios f ON f.funcionarioId = em.funcionarioId
    LEFT JOIN pontuacaofuncionario pf ON f.funcionarioId = pf.id_funcionario
    WHERE em.id_equipe = :id_equipe
    GROUP BY f.funcionarioId, f.nome
    ORDER BY pontos DESC;
");
    $query->bindValue(':id_equipe', $id_equipe, PDO::PARAM_INT);
    $query->execute();
    
    $pontosfuncionario = $query->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'success' => true,
        'result' => $pontosfuncionario
    ]);

} catch (PDOException $e) {
    error_log("Erro no banco de dados: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Erro no banco de dados'
    ]);
}
?>